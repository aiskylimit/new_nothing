import json

import requests

from ..smp import get_logger
from .base import BaseAPI

logger = get_logger(__name__)


def _apply_response_charset(response, response_charset):
    if response_charset is None:
        return

    content_type = ''.join(response.headers.get('Content-Type', '').lower().split())
    if 'charset=' in content_type:
        return

    response.encoding = response_charset


def _parse_stream_chunk(chunk: dict):
    choices = chunk.get('choices', [])
    if not choices:
        return ''
    delta = choices[0].get('delta', {})
    if not isinstance(delta, dict):
        return ''
    return delta.get('content') or ''


def _collect_streaming_content(response, verbose=False):
    answer_parts = []
    chunk_count = 0
    for line in response.iter_lines(decode_unicode=True):
        if not line:
            continue
        line = line.strip()
        if not line.startswith('data:'):
            continue
        data = line[5:].strip()
        if data == '[DONE]':
            break
        try:
            chunk = json.loads(data)
        except json.JSONDecodeError:
            if verbose:
                logger.warning(f'Invalid streaming chunk: {data[:120]}')
            continue
        part = _parse_stream_chunk(chunk)
        if part:
            answer_parts.append(part)
            chunk_count += 1
    answer = ''.join(answer_parts).strip()
    if verbose:
        logger.info(
            f'Streaming finished: chunks={chunk_count}, chars={len(answer)}'
        )
    return answer


class OpenAISDKWrapper(BaseAPI):
    """Base class for OpenAI-compatible API wrappers.

    Provides a standard ``generate_inner`` implementation with optional
    :class:`~vlmeval.api.adapters.ModelAdapter` support for model-specific
    prompt building and payload processing.

    Subclasses **must** implement :meth:`prepare_inputs` to convert the
    internal message list into the HTTP message format expected by their
    specific API endpoint.

    Attributes:
        adapter: An optional :class:`ModelAdapter` instance. Set to
            ``None`` to disable adapter hooks.
        key (str): API authentication key.
        api_base (str): Full URL of the chat completions endpoint.
        model (str): Model identifier sent in the request payload.
        timeout (int): HTTP request timeout in seconds.
    """

    is_api: bool = True

    def __init__(self,
                 retry=5,
                 wait=5,
                 verbose=True,
                 system_prompt=None,
                 model_adapter=None,
                 stream=False,
                 response_charset='utf-8',
                 **kwargs):
        """
        Args:
            model_adapter: Either a :class:`ModelAdapter` instance, a
                registered adapter name (``str``), or ``None``.
            response_charset: Charset used to decode HTTP responses that do
                not declare a charset in the Content-Type header. Defaults to
                ``utf-8``. Set to ``None`` to keep requests' inferred encoding.
        """
        self.adapter = None
        self.stream = stream
        self.response_charset = response_charset
        if model_adapter is not None:
            if isinstance(model_adapter, str):
                from .adapters import build_adapter
                self.adapter = build_adapter(model_adapter)
            else:
                self.adapter = model_adapter

        super().__init__(
            retry=retry,
            wait=wait,
            system_prompt=system_prompt,
            verbose=verbose,
            **kwargs,
        )

    # ------------------------------------------------------------------
    # Adapter integration
    # ------------------------------------------------------------------

    def set_dump_image(self, dump_image_func):
        if self.adapter is not None:
            self.adapter.dump_image_func = dump_image_func
        self.dump_image_func = dump_image_func

    def use_custom_prompt(self, dataset) -> bool:
        if self.adapter is not None:
            return self.adapter.use_custom_prompt(dataset, self.system_prompt)
        return False

    def build_prompt(self, line, dataset=None):
        if self.adapter is not None:
            return self.adapter.build_prompt(line, dataset)
        raise NotImplementedError

    # ------------------------------------------------------------------
    # HTTP formatting – subclasses must override
    # ------------------------------------------------------------------

    def prepare_inputs(self, inputs, system_prompt):
        """Convert the internal message list to HTTP message dicts.

        Args:
            inputs: List of ``{'type': ..., 'value': ...}`` dicts, or a
                list of role-keyed dicts for multi-turn conversations.
            system_prompt: System prompt string, or ``None``.

        Returns:
            List of OpenAI-style message dicts with ``role`` and
            ``content`` fields.
        """
        raise NotImplementedError(
            f'{type(self).__name__} must implement prepare_inputs()'
        )

    # ------------------------------------------------------------------
    # Core generation loop
    # ------------------------------------------------------------------

    def generate_inner(self, inputs, dataset=None, **kwargs) -> tuple:
        if self.adapter is not None:
            model_args = self.adapter.override_model_args(dataset, kwargs)
            system_prompt = model_args.pop('system_prompt', self.system_prompt)
            inputs = self.adapter.process_inputs(inputs, dataset)
            kwargs.update(model_args)
        else:
            system_prompt = self.system_prompt

        input_msgs = self.prepare_inputs(inputs, system_prompt)

        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.key}',
        }
        payload = dict(model=self.model, messages=input_msgs, n=1, **kwargs)
        stream = payload.pop('stream', self.stream)
        if stream:
            payload['stream'] = True

        if self.adapter is not None:
            payload = self.adapter.process_payload(payload, dataset=dataset)

        response = requests.post(
            self.api_base,
            headers=headers,
            data=json.dumps(payload),
            timeout=self.timeout * 1.1,
            stream=stream,
        )
        _apply_response_charset(response, self.response_charset)
        ret_code = response.status_code
        ret_code = 0 if (200 <= int(ret_code) < 300) else ret_code
        answer = self.fail_msg
        try:
            if stream and ret_code == 0:
                answer = _collect_streaming_content(response, verbose=self.verbose)
            else:
                resp_struct = json.loads(response.text)
                answer = resp_struct['choices'][0]['message']['content'].strip()
            if self.adapter is not None:
                answer = self.adapter.postprocess(answer, dataset=dataset)
        except Exception as err:
            logger.error(f'{type(err)}: {err}')
            if self.verbose:
                logger.error(response.text if hasattr(response, 'text') else response)
        return ret_code, answer, response
